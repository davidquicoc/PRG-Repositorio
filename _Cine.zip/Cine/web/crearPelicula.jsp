<%@page import="java.sql.Connection"%>
<%@page import="java.sql.Statement"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="programas.ConexionBD"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Modificar película</title>
    </head>
    <body>
        <h1>Hello World!</h1>
        <%
            Connection conexion = ConexionBD.conectar();

            if (conexion == null) {
                response.sendRedirect("./error");
                return;
            }

            conexion.close();
        %>

        <form method="post" action="insertarPelicula.jsp">

            <label>ID de la película: </label>
            <input type="text" name="ID_pelicula" required>

            <br>

            <label>Título: </label>
            <input type="text" name="titulo" required>

            <br>

            <label>Género: </label>
            <input type="text" name="genero" required>

            <br>

            <label>Duración: </label>
            <input type="number" name="duracion" required>

            <br>

            <label>Año: </label>
            <input type="number" name="año" required>

            <br>

            <label>Clasificación: </label>
            <select name="clasificacion">
                <option value="G">G - Para todas las edades</option>
                <option value="PG">PG - Supervisión sugerida</option>
                <option value="PG-13">PG-13 - +13</option>
                <option value="R">R - +17 con supervisión</option>
                <option value="NC-17">NC-17 - Solo adultos</option>
            </select>

            <br>

            <label>URL de la imagen: </label>
            <input type="url" name="url" placeholder="https://pics.filmaffinity.com/..." required>

            <br>

            <label for="est1">Alta</label>
            <input type="radio" id="est1" name="estado_pelicula" value="true" checked>

            <br>
            <label for="est2">Baja</label>
            <input type="radio" id="est2" name="estado_pelicula" value="false">

            <br>

            <a href="index.jsp"Cancelar</a>
            <input type="submit" value="Enviar">
        </form>

    </body>
</html>
