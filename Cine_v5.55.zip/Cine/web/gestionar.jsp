<%@page import="java.sql.Statement"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@page import="programas.ConexionBD"%>
<%@page import="programas.ExportarDatos"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Gestionar</title>
        <link rel="stylesheet" type="text/css" href="css/gestionar.css">
    </head>
    <body>
        <%
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = ConexionBD.conectar();

            if (conexion == null) {
                response.sendRedirect("../error/");
                return;
            }

            Statement stmt = conexion.createStatement();
        %>
        <div class="contenedor">
            <header>
                <div class="header-logo">
                    <a href="#">
                        <h2>LOGO</h2>
                    </a>
                </div>
                <nav class="header-nav">
                    <ul>
                        <li><a href="index.jsp">Inicio</a></li>
                        <li><a href="peliculas.jsp">Películas</a></li>
                        <li><a href="calendario.jsp">Calendario</a></li>
                            <%
                                if (session.getAttribute("usuario") != null) {
                            %>
                        <li><a href="gestionar.jsp">Gestionar</a></li>
                            <%
                                }
                            %>
                    </ul>
                </nav>
                <div class="header-user">
                    <%
                        if (session.getAttribute("usuario") == null) {
                    %>
                    <a href="login/">Iniciar sesión</a>
                    <%
                    } else {
                    %>
                    <a href="user-profile.jsp"><%= session.getAttribute("usuario")%></a>
                    <%
                        }
                    %>
                </div>
            </header>
            <main>
                <h2>Gestión de películas</h2>
                <section class="pelicula">
                    <div class="div-pelicula">
                        <form method="post" action="crearPelicula.jsp">
                            <div>
                                <label for="ID_pelicula">ID</label>
                                <input type="text" size="4" id="ID_pelicula" name="ID_pelicula" placeholder="P####">
                            </div>
                            <div>
                                <label for="titulo">Título</label>
                                <input type="text" id="titulo" name="titulo">
                            </div>
                            <div>
                                <label for="genero">Genero</label>
                                <input type="text" size="7" id="genero" name="genero">
                            </div>
                            <div>
                                <label for="duracion">Duración</label>
                                <input type="number" id="duracion" name="duracion" min="0">
                            </div>
                            <div>
                                <label for="año">Año</label>
                                <input type="number" id="año" name="año">
                            </div>
                            <div>
                                <label for="clasificacion">Clasificación</label>
                                <select id="clasificacion" name="clasificacion">
                                    <option value="G">G - Para todas las edades</option>
                                    <option value="PG">PG - Supervisión sugerida</option>
                                    <option value="PG-13">PG-13 - +13</option>
                                    <option value="R">R - +17 con supervisión</option>
                                    <option value="NC-17">NC-17 - Solo adultos</option>
                                </select>
                            </div>
                            <div>
                                <label for="url">URL</label>
                                <input type="url" id="url" name="url" placeholder="https://pics.filmaffinity.com/...">
                            </div>
                            <div>
                                <p>Estado</p>
                                <p><input type="radio" id="est1" name="estado_pelicula" value="true" checked>&nbsp;<label for="est1">Alta</label></p>
                                <p><input type="radio" id="est2" name="estado_pelicula" value="false">&nbsp;<label for="est2">Baja</label></p> 
                            </div>
                            <div>
                                <input type="submit" value="Agregar">
                            </div>
                        </form>
                    </div>
                    <div class="bloques-pelicula">
                        <%
                            ResultSet rsP = stmt.executeQuery("SELECT * FROM pelicula");
                            while (rsP.next()) {
                        %>
                        <div class="bloque-pelicula">
                            <div class="pelicula-contenedor">
                                <div class="pelicula-imagen">
                                    <img src="<%=rsP.getString("url")%>" alt="<%=ExportarDatos.exportar(rsP.getString("titulo"))%>" width="100">
                                </div>
                                <div class="pelicula-info">
                                    <p><b>ID:</b>&nbsp;<span class="datosP"><%=rsP.getString("ID_pelicula")%></span></p>
                                    <p><b>Título:</b>&nbsp;<span class="datosP"><%=rsP.getString("titulo")%></span></p>
                                    <p><b>Género:</b>&nbsp;<span class="datosP"><%=rsP.getString("genero")%></span></p>
                                    <p><b>Duración:</b>&nbsp;<span class="datosP"><%=rsP.getInt("duracion")%></span></p>
                                    <p><b>Año:</b>&nbsp;<span class="datosP"><%=rsP.getInt("año")%></span></p>
                                    <p><b>Clasificación:</b>&nbsp;<span class="datosP"><%=rsP.getString("clasificacion")%></span></p>
                                    <p><b>URL:</b>&nbsp;<span class="datosP"><%=rsP.getString("url")%></span></p>
                                    <p><b>Estado:</b>&nbsp;<span class="datosP"><%=(rsP.getBoolean("estado_pelicula") ? "Disponible" : "No disponible")%></span></p>
                                </div>
                            </div>
                            <div class="pelicula-botones">
                                <form method="get" action="modificarPelicula.jsp">
                                    <input type="hidden" name="ID_pelicula" value="<%=rsP.getString("ID_pelicula")%>">
                                    <input type="hidden" name="titulo" value="<%=rsP.getString("titulo")%>">
                                    <input type="hidden" name="genero" value="<%=rsP.getString("genero")%>">
                                    <input type="hidden" name="duracion" value="<%=rsP.getInt("duracion")%>">
                                    <input type="hidden" name="año" value="<%=rsP.getInt("año")%>">
                                    <input type="hidden" name="clasificacion" value="<%=rsP.getString("clasificacion")%>">
                                    <input type="hidden" name="url" value="<%=rsP.getString("url")%>">
                                    <input type="hidden" name="estado_pelicula" value="<%=rsP.getString("estado_pelicula")%>">
                                    <input type="submit" value="Modificar">
                                </form>
                                <form method="get" action="eliminarPelicula.jsp">
                                    <input type="hidden" name="ID_pelicula" value="<%=rsP.getString("ID_pelicula")%>">
                                    <input type="submit" value="Eliminar">
                                </form>
                            </div>
                        </div>
                        <%
                            }
                            rsP.close();
                        %>
                    </div>
                </section>
                <section class="salas">
                    <h2>Salas guardadas</h2>
                    <div class="bloque-crear-sala">
                        <form method="post" action="#">
                            <div>
                                <label for="ID_sala">ID</label>
                                <input type="text" size="4" id="ID_sala" name="ID_sala" placeholder="SA###">
                            </div>
                            <div>
                                <label for="nombre">Nombre</label>
                                <input type="text" id="nombre" name="nombre">
                            </div>
                            <div>
                                <label for="numeroAsientos">Nº Asiento</label>
                                <input type="number" id="numeroAsientos" name="numeroAsientos">
                            </div>
                            <div>
                                <p>P. Minusválido</p>
                                <p><input type="radio" id="p1" name="plazasMinusvalido" value="true" checked>&nbsp;<label for="p1">Si</label></p>
                                <p><input type="radio" id="p2" name="plazasMinusvalido" value="false" checked>&nbsp;<label for="p2">No</label></p> 
                            </div>
                            <div>
                                <p>Estado</p>
                                <p><input type="radio" id="estSa1" name="estado_sala" value="true" checked>&nbsp;<label for="estSa1">Si</label></p>
                                <p><input type="radio" id="estSa2" name="estado_sala" value="false" checked>&nbsp;<label for="estSa2">No</label></p> 
                            </div>
                            <div>
                                <input type="submit" value="Agregar">
                            </div>
                        </form>
                    </div>
                    <%
                        ResultSet rsSa = stmt.executeQuery("SELECT * FROM sala");
                        while (rsSa.next()) {
                    %>
                    <div class="info-sala">
                        <div class="sala-bloque">
                            <p><b><%=rsSa.getString("ID_sala")%></b>&nbsp;|&nbsp;<b><%=rsSa.getString("nombre")%></b> - Capacidad: <%=rsSa.getInt("numeroAsientos")%>&nbsp;
                                <%
                                    if (rsSa.getBoolean("plazasMinusvalido")) {
                                        out.print("♿");
                                    } else {
                                        out.print("Sin plazas para minúsvalidos");
                                    }
                                %>
                                &nbsp;
                                |&nbsp;Estado: <%=(rsSa.getBoolean("estado_sala") ? "Disponible" : "No disponible")%>
                            </p>
                        </div>
                        <div class="sala-button">
                            <form method="get" action="modificarSala.jsp">
                                <input type="hidden" name="ID_sala" value="<%=rsSa.getString("ID_sala")%>">
                                <input type="hidden" name="nombre" value="<%=rsSa.getString("nombre")%>">
                                <input type="hidden" name="numeroAsientos" value="<%=rsSa.getInt("numeroAsientos")%>">
                                <input type="hidden" name="plazasMinusvalido" value="<%=rsSa.getString("plazasMinusvalido")%>">
                                <input type="hidden" name="estado_sala" value="<%=rsSa.getString("estado_sala")%>">
                                <input type="submit" value="Modificar">
                            </form>
                            <form method="get" action="eliminarSala.jsp">
                                <input type="hidden" name="ID_sala" value="<%=rsSa.getString("ID_sala")%>">
                                <input type="submit" value="Eliminar">
                            </form>
                        </div>
                    </div>
                    <%
                        }
                        rsSa.close();
                    %>
                </section>
                <section class="sesiones">
                    <h2>Gestión de sesiones</h2>
                    <div class="crearSesion">
                        <form method="post" action="crearSesion.jsp">
                            <div>
                                <label for="ID_sesion">ID</label>
                                <input type="text" size="4" id="ID_sesion" name="ID_sesion" placeholder="SE###">
                            </div>
                            <div>
                                <label for="ID_peliculaSe">Película ID Ref</label>
                                <select id="ID_peliculaSe" name="ID_pelicula">
                                    <%
                                        String sqlP = "SELECT ID_pelicula, titulo FROM pelicula";
                                        ResultSet rsPSelect = stmt.executeQuery(sqlP);
                                        while (rsPSelect.next()) {
                                    %>
                                    <option value="<%=rsPSelect.getString("ID_pelicula")%>"><%=rsPSelect.getString("titulo")%></option>
                                    <%
                                        }
                                        rsPSelect.close();
                                    %>
                                </select>
                            </div>
                            <div>
                                <label for="ID_salaSe">Sala ID Ref</label>
                                <select id="ID_salaSe" name="ID_sala">
                                    <%
                                        String sqlSa = "SELECT ID_sala, nombre FROM sala";
                                        ResultSet rsSaSelect = stmt.executeQuery(sqlSa);
                                        while (rsSaSelect.next()) {
                                    %>
                                    <option value="<%=rsSaSelect.getString("ID_sala")%>"><%=rsSaSelect.getString("nombre")%></option>
                                    <%
                                        }
                                        rsSaSelect.close();
                                    %>
                                </select>
                            </div>
                            <div>
                                <label for="Fecha_Hora">Fecha y hora</label>
                                <input type="text" size="4" id="Fecha_Hora" name="Fecha_Hora">
                            </div>
                            <div>
                                <input type="submit" value="Enviar">
                            </div>
                        </form>
                    </div>
                    <%
                        ResultSet rsSe = stmt.executeQuery("SELECT * FROM sesion");
                        while (rsSe.next()) {
                            String idPelicula = rsSe.getString("ID_pelicula");
                            String idSala = rsSe.getString("ID_sala");

                            Statement stmtP = conexion.createStatement();
                            Statement stmtS = conexion.createStatement();

                            ResultSet rsPelicula = stmtP.executeQuery("SELECT estado_pelicula FROM pelicula WHERE ID_pelicula = '" + idPelicula + "' AND estado_pelicula=TRUE");
                            ResultSet rsSala = stmtS.executeQuery("SELECT estado_sala FROM sala WHERE ID_sala = '" + idSala + "' AND estado_sala=TRUE");
                            if (rsPelicula.next() && rsSala.next()) {
                    %>
                    <div class="bloqueSesiones">
                        <div class="bloqueSesion">
                            <p><b>ID:&nbsp;</b><%=rsSe.getString("ID_sesion")%></p>
                            <p><b>Película:&nbsp;</b><%=rsSe.getString("ID_pelicula")%></p>
                            <p><b>Sala:&nbsp;</b><%=rsSe.getString("ID_sala")%></p>
                            <p><b>Fecha y hora&nbsp;</b><%=rsSe.getTimestamp("Fecha_Hora")%></p>
                        </div>
                        <div class="sesion-boton">
                            <form method="get" action="modificarSesion.jsp">
                                <input type="hidden" name="ID_sesion" value="<%=rsSe.getString("ID_sesion")%>">
                                <input type="hidden" name="ID_pelicula" value="<%=rsSe.getString("ID_pelicula")%>">
                                <input type="hidden" name="ID_sala" value="<%=rsSe.getString("ID_sala")%>">
                                <input type="hidden" name="Fecha_Hora" value="<%=rsSe.getString("Fecha_Hora")%>">
                                <input type="submit" value="Modificar">
                            </form>
                            <form method="get" action="eliminarSesion.jsp">
                                <input type="hidden" name="ID_sesion" value="<%=rsSe.getString("ID_sesion")%>"/>
                                <input type="submit" value="Eliminar">
                            </form>
                        </div>
                    </div>
                    <%
                            }
                            rsPelicula.close();
                            rsSala.close();
                        }
                        rsSe.close();
                    %>
                </section>
                <section>
                    <h3>Exportar datos</h3>
                    <%
                        String tabla = request.getParameter("tabla");
                        if (tabla != null) {
                            boolean resultado = ExportarDatos.exportar(tabla);
                            if (resultado) {
                    %>
                    <p>Datos de <%= tabla%> exportados</p>
                    <p><a href="files/<%= tabla%>.txt" download>Descargar <%= tabla%></a></p>
                    <%
                    } else {
                    %>
                    <p style="color: red;">Error al exportar los datos de <%= tabla%></p>
                    <%
                            }
                        }
                    %>
                    <ul>
                        <li><a href="gestionar.jsp?tabla=pelicula">Exportar películas</a></li>
                        <li><a href="gestionar.jsp?tabla=sala">Exportar salas</a></li>
                        <li><a href="gestionar.jsp?tabla=sesion">Exportar sesiones</a></li>
                    </ul>
                </section>
            </main>
        </div>
    </body>
</html>