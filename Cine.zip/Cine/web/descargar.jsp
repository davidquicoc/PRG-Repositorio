<%@page import="programas.ExportarDatos"%>
<%
    String tabla = request.getParameter("tabla");
    boolean exportado = false;
    
    if (tabla != null) {
        exportado = ExportarDatos.exportar(tabla);
    }
    
    if (exportado) {
        out.println("<p>Archivado exportado correctamente a tu carpeta Descargas.</p>");
    } else {
        out.println("<p>Error al exportar los datos.</p>");
    }
%>