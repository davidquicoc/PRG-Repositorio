<%@page import="java.sql.Connection"%>
<%@page import="java.sql.Statement"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="programas.ConexionBD"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Peliculas - Cine</title>
        <link rel="stylesheet" href="css/peliculas.css">
    </head>
    <body>
        <h2>Películas en la Base de Datos</h2>
        <%
            Connection conexion = ConexionBD.conectar();
            
            if (conexion == null) {
                response.sendRedirect("./error");
                return;
            }
            
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM pelicula ORDER BY titulo");
            %>
            <h4>Peliculas dadas de alta</h4>
            <%
            while (rs.next()) {
                if (rs.getBoolean("estado_pelicula")) {
            %>
            <div class="bloque">
            <%
                    out.println(rs.getString("ID_pelicula") + " | " + rs.getString("titulo") + " | " + rs.getString("genero") + " | " + rs.getInt("duracion") + " | " + rs.getInt("año") + " | " + rs.getString("clasificacion") + " | " + rs.getString("url") + " | " + rs.getBoolean("estado_pelicula") + "<br>");
                    out.println("<img src=\"" + rs.getString("url") + "\">");
                }%>
            </div>
            <%
            }
            %>
            <h4>Peliculas dadas de baja</h4>
            <%
            //  Crear conjunto de peliculas.
            /*while (rs.next()) {
                if (!rs.getBoolean("estado")) { 
                    out.println(rs.getString("ID_pelicula") + " | " + rs.getString("titulo") + " | " + rs.getString("genero") + " | " + rs.getInt("duracion") + " | " + rs.getInt("año") + " | " + rs.getString("clasificacion") + " | " + "<br>");
                }
            }*/
            
            conexion.close();
        %>
    </body>
</html>
