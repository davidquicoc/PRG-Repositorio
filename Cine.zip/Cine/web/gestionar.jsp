<%@page import="java.sql.Statement"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@page import="programas.ConexionBD"%>
<%@page import="programas.ExportarDatos"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Gestionar - Cine</title>
    </head>
    <body>
        <%
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = ConexionBD.conectar();

            if (conexion == null) {
                response.sendRedirect("../error/");
                return;
            }

            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM pelicula");
        %>
        <table class="table table-striped">
            <tr><th>ID de película</th><th>Título</th><th>Género</th><th>Duración</th><th>Año</th><th>Clasificación</th><th>URL imagen</th><th>Estado</th></tr>
            <form>
                <tr>
                    <td><input type="text" name="ID_pelicula" size="5"></td>
                    <td><input type="text" name="titulo" size="30"></td>
                    <td><input type="text" name="genero" size="5"></td>
                    <td><input type="number" name="duracion" size="5"></td>
                    <td><input type="number" name="año" size="5"></td>
                    <td><input type="text" name="clasificacion" size="6" min="0" max="10"></td>
                    <td><input type="url" name="url"></td>
                    <td>
                        <label for="est1">Alta</label>
                        <input type="radio" id="est1" name="estado_pelicula" value="v">
                        <label for="est2">Baja</label>
                        <input type="radio" id="est2" name="estado_pelicula" value="f">
                    </td>
                    <td><button type="submit" value="Añadir" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Añadir</button></td>
                    <td></td>
                </tr>
            </form>
            <%
                while (rs.next()) {
                    out.println("<tr><td>");
                    out.println(rs.getString("ID_pelicula") + "</td>");
                    out.println("<td>" + rs.getString("titulo") + "</td>");
                    out.println("<td>" + rs.getString("genero") + "</td>");
                    out.println("<td>" + rs.getInt("duracion") + "</td>");
                    out.println("<td>" + rs.getInt("año") + "</td>");
                    out.println("<td>" + rs.getString("clasificacion") + "</td>");
                    out.println("<td>" + rs.getString("url") + "</td>");
                    out.println("<td>" + rs.getBoolean("estado_pelicula") + "</td>");
            %>
            <td>
                <form method="get" action="#">
                    <input type="hidden" name="ID_pelicula" value="<%=rs.getString("ID_pelicula")%>">
                    <input type="hidden" name="titulo" value="<%=rs.getString("titulo")%>">
                    <input type="hidden" name="duracion" value="<%=rs.getInt("duracion")%>">
                    <input type="hidden" name="año" value="<%=rs.getInt("año")%>">
                    <input type="hidden" name="clasificacion" value="<%=rs.getString("clasificacion")%>">
                    <input type="hidden" name="url" value="<%=rs.getString("url")%>">
                    <input type="hidden" name="estado_pelicula" value="<%=rs.getString("estado_pelicula")%>">
                    <button type="submit"  class="btn btn-info"><span class="glyphicon glyphicon-pencil"></span> Modificar</button>
                </form>
            </td>
            <td>
                <form method="get" action="#">
                    <input type="hidden" name="ID_pelicula" value="<%=rs.getString("ID_pelicula")%>"/>
                    <button type="submit" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span> Eliminar</button>
                </form>
            </td></tr>
            <%
                } // while   

                conexion.close();
            %>
    </table>
    <ul>
        <li><a href="gestionar.jsp?tabla=pelicula">Exportar películas</a></li>
        <li><a href="gestionar.jsp?tabla=sala">Exportar salas</a></li>
        <li><a href="gestionar.jsp?tabla=sesion">Exportar sesiones</a></li>
    </ul>
</body>
</html>