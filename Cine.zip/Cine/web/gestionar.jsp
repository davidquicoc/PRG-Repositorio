<%@page import="java.sql.Statement"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@page import="programas.ConexionBD"%>
<%@page import="programas.ExportarDatos"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Gestionar</title>
        <link rel="stylesheet" href="css/gestionar.css">
    </head>
    <body>
        <div class="contenedor">
        <main>
            <%
                Class.forName("com.mysql.jdbc.Driver");
                Connection conexion = ConexionBD.conectar();

                if (conexion == null) {
                    response.sendRedirect("../error/");
                    return;
                }

                Statement stmt = conexion.createStatement();
            %>
            <h3>Películas</h3>
            <section class="pelicula">
                <div class="div-pelicula">
                    <form mehtod="post" action="crearPelicula.jsp">
                        <div>
                            <label for="idP">ID</label>
                            <input type="text" size="4" id="idP" name="ID_pelicula" placeholder="P####">
                        </div>
                        <div>
                            <label for="titP">Título</label>
                            <input type="text" id="titP" name="titulo">
                        </div>
                        <div>
                            <label for="genP">Genero</label>
                            <input type="text" size="7" id="genP" name="genero">
                        </div>
                        <div>
                            <label for="durP">Duración</label>
                            <input type="number" id="durP" name="duracion" min="0">
                        </div>
                        <div>
                            <label for="añoP">Año</label>
                            <input type="number" id="añoP" name="año">
                        </div>
                        <div>
                            <label for="clasifP">Clasificación</label>
                            <select name="clasificacion">
                                <option value="G">G - Para todas las edades</option>
                                <option value="PG">PG - Supervisión sugerida</option>
                                <option value="PG-13">PG-13 - +13</option>
                                <option value="R">R - +17 con supervisión</option>
                                <option value="NC-17">NC-17 - Solo adultos</option>
                            </select>
                        </div>
                        <div>
                            <label for="urlP">URL</label>
                            <input type="url" id="urlP" name="url" placeholder="https://pics.filmaffinity.com/...">
                        </div>
                        <div>
                            <p>Estado</p>
                            <p><input type="radio" id="est1" name="estado_pelicula" value="true" checked>&nbsp;<label for="est1">Alta</label></p>
                            <p><input type="radio" id="est2" name="estado_pelicula" value="false" checked>&nbsp;<label for="est2">Alta</label></p> 
                        </div>
                        <div>
                            <input type="submit" value="Agregar">
                        </div>
                    </form>
                </div>
                <div class="bloques">
                    <%
                        ResultSet rsP = stmt.executeQuery("SELECT * FROM pelicula");
                        while (rsP.next()) {
                    %>
                    <div class="bloque">
                        <div class="bloque-pelicula">
                            <div class="bloque-imagen">
                                <img src="<%=rsP.getString("url")%>" alt="<%=ExportarDatos.exportar(rsP.getString("titulo"))%>" width="100">
                            </div>
                            <div class="bloque-info">
                                <p><b>ID:</b>&nbsp;<span class="datosP"><%=rsP.getString("ID_pelicula")%></span></p>
                                <p><b>Título:</b>&nbsp;<span class="datosP"><%=rsP.getString("titulo")%></span></p>
                                <p><b>Género:</b>&nbsp;<span class="datosP"><%=rsP.getString("genero")%></span></p>
                                <p><b>Duración:</b>&nbsp;<span class="datosP"><%=rsP.getInt("duracion")%></span></p>
                                <p><b>Año:</b>&nbsp;<span class="datosP"><%=rsP.getInt("año")%></span></p>
                                <p><b>Clasificación:</b>&nbsp;<span class="datosP"><%=rsP.getString("clasificacion")%></span></p>
                                <p><b>URL:</b>&nbsp;<span class="datosP"><%=rsP.getString("url")%></span></p>
                                <p><b>Estado:</b>&nbsp;<span class="datosP"><%=(rsP.getBoolean("estado_pelicula") ? "Disponible" : "No disponible")%></span></p>
                            </div>
                        </div>
                        <div class="bloque-botones">
                            <form method="get" action="modificarPelicula.jsp">
                                <input type="hidden" name="ID_pelicula" value="<%=rsP.getString("ID_pelicula")%>">
                                <input type="hidden" name="titulo" value="<%=rsP.getString("titulo")%>">
                                <input type="hidden" name="genero" value="<%=rsP.getString("genero")%>">
                                <input type="hidden" name="duracion" value="<%=rsP.getInt("duracion")%>">
                                <input type="hidden" name="año" value="<%=rsP.getInt("año")%>">
                                <input type="hidden" name="clasificacion" value="<%=rsP.getString("clasificacion")%>">
                                <input type="hidden" name="url" value="<%=rsP.getString("url")%>">
                                <input type="hidden" name="estado_pelicula" value="<%=rsP.getString("estado_pelicula")%>">
                                <input type="submit" value="Modificar">
                            </form>
                            <form method="get" action="eliminarPelicula.jsp">
                                <input type="hidden" name="ID_pelicula" value="<%=rsP.getString("ID_pelicula")%>">
                                <input type="submit" value="Modificar">
                            </form>
                        </div>
                    </div>
                    <%
                        }
                        rsP.close();
                    %>
                </div>
                </div>
            </section>
            <section class="salas">
                <h2>Salas guardadas</h2>
                <div class="salas-div">
                    <div class="sala">
                        <div class="div-formSa">
                            <form method="post" action="#">
                                <div>
                                    <label for="idSa">ID</label>
                                    <input type="text" size="4" id="idSa" name="ID_sala" placeholder="SA###">
                                </div>
                                <div>
                                    <label for="nomSa">Nombre</label>
                                    <input type="text" id="nomSa" name="nombre">
                                </div>
                                <div>
                                    <label for="numAsiSa">Nº Asiento</label>
                                    <input type="number" id="numAsiSa" name="numeroAsientos">
                                </div>
                                <div>
                                    <label for="durP">Duración</label>
                                    <input type="number" id="durP" name="duracion" min="0">
                                </div>
                                <div>
                                    <p>P. Minusválido</p>
                                    <p><input type="radio" id="p1" name="plazasMinusvalido" value="true" checked>&nbsp;<label for="p1">Si</label></p>
                                    <p><input type="radio" id="p2" name="plazasMinusvalido" value="false" checked>&nbsp;<label for="p2">No</label></p> 
                                </div>
                                <div>
                                    <p>Estado</p>
                                    <p><input type="radio" id="estSa1" name="estado_sala" value="true" checked>&nbsp;<label for="estSa1">Si</label></p>
                                    <p><input type="radio" id="estSa2" name="estado_sala" value="false" checked>&nbsp;<label for="estSa2">No</label></p> 
                                </div>
                                <div>
                                    <input type="submit" value="Agregar">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <%
                    ResultSet rsSa = stmt.executeQuery("SELECT * FROM sala");
                    while (rsSa.next()) {
                %>
                <div class="bloque-sala">
                    <div class="sala-info">
                        <p>
                            <b><%=rsSa.getString("ID_sala")%></b> | 
                            <b><%=rsSa.getString("nombre")%></b> - 
                            Capacidad: <%=rsSa.getInt("numeroAsientos")%>
                            &nbsp;
                            <%
                                if (rsSa.getBoolean("plazasMinusvalido")) {
                                    out.print("♿");
                                } else {
                                    out.print("Sin plazas para minúsvalidos");
                                }
                            %>
                            &nbsp;
                            | Estado: <%=(rsSa.getBoolean("estado_pelicula") ? "Disponible" : "No disponible")%>
                        </p>
                    </div>
                        <div class="sala-button">
                            <form method="get" action="modificarSala.jsp">
                                <input type="hidden" name="ID_sala" value="<%=rsP.getString("ID_sala")%>">
                                <input type="hidden" name="nombre" value="<%=rsP.getString("nombre")%>">
                                <input type="hidden" name="numeroAsientos" value="<%=rsP.getInt("numeroAsientos")%>">
                                <input type="hidden" name="plazasMinusvalido" value="<%=rsP.getInt("plazasMinusvalido")%>">
                                <input type="hidden" name="estado_sala" value="<%=rsP.getString("estado_sala")%>">
                                <input type="submit" value="Modificar">
                            </form>
                        </div>
                </div>
                <%
                    }
                    rsSa.close();
                %>
            </section>
            <hr>

            <a href="crearSesion.jsp">Crear sesión nueva</a>
            <table border="1">
                <tr>
                    <th>ID</th>
                    <th>ID Película</th>
                    <th>ID Sala</th>
                    <th>Fecha y hora</th>
                    <th>&nbsp;</th>
                </tr>
                <%
                    ResultSet rsSe = stmt.executeQuery("SELECT * FROM sesion");
                    while (rsSe.next()) {
                %>
                <tr>
                    <td><%=rsSe.getString("ID_sesion")%></td>
                    <td><%=rsSe.getString("ID_pelicula")%></td>
                    <td><%=rsSe.getString("ID_sala")%></td>
                    <td><%=rsSe.getString("Fecha_Hora")%></td>
                    <td>
                        <form method="get" action="modificarSesion.jsp">
                            <input type="hidden" name="ID_sesion" value="<%=rsSe.getString("ID_sesion")%>">
                            <input type="hidden" name="ID_pelicula" value="<%=rsSe.getString("ID_pelicula")%>">
                            <input type="hidden" name="ID_sala" value="<%=rsSe.getString("ID_sala")%>">
                            <input type="hidden" name="Fecha_Hora" value="<%=rsSe.getString("Fecha_Hora")%>">
                            <input type="submit" value="Modificar">
                        </form>
                        <br>
                        <form method="get" action="eliminarSala.jsp">
                            <input type="hidden" name="ID_sesion" value="<%=rsSe.getString("ID_sesion")%>"/>
                            <input type="submit" value="Eliminar">
                        </form>
                    </td>
                </tr>
                <%
                    }
                    rsSe.close();
                    stmt.close();
                    conexion.close();
                %>
            </table>

            <hr>

            <h3>Exportar datos</h3>
            <%
                String tabla = request.getParameter("tabla");
                if (tabla != null) {
                    boolean resultado = ExportarDatos.exportar(tabla);
                    if (resultado) {
            %>
            <p>Datos de <%= tabla%> exportados</p>
            <p><a href="files/<%= tabla%>.txt" download>Descargar <%= tabla%></a></p>
            <%
            } else {
            %>
            <p style="color: red;">Error al exportar los datos de <%= tabla%></p>
            <%
                    }
                }
            %>
            <ul>
                <li><a href="gestionar.jsp?tabla=pelicula">Exportar películas</a></li>
                <li><a href="gestionar.jsp?tabla=sala">Exportar salas</a></li>
                <li><a href="gestionar.jsp?tabla=sesion">Exportar sesiones</a></li>
            </ul>
        </main>
        </div>
    </body>
</html>