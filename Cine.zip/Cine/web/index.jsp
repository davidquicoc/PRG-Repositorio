<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <div class="contenedor">
            <header>
                <div class="header-logo">
                    <a href="#">
                        <h2>LOGO</h2>
                    </a>
                </div>
                <nav class="header-nav">
                    <ul>
                        <li><a href="index.jsp">Inicio</a></li>
                        <li><a href="peliculas.jsp">Películas</a></li>
                        <li><a href="calendario.jsp">Calendario</a></li>
                        <%
                        if (session.getAttribute("usuario") != null) {
                        %>
                        <li><a href="gestionar.jsp">Gestionar</a></li>
                        <%
                            }
                        %>
                    </ul>
                </nav>
                <div class="header-user">
                    <%
                        if (session.getAttribute("usuario") == null) {
                    %>
                        <a href="login/">Iniciar sesión</a>
                    <%
                        } else {
                    %>
                        <a href="user-profile.jsp"><%= session.getAttribute("usuario") %></a>
                    <%
                        }
                    %>
                </div>
            </header>
            <main>
                <h3>Sesiones</h3>
                <%
                    out.println("XD:" + System.getProperty("user.dir"));
                %>
            </main>
        </div>
    </body>
</html>
