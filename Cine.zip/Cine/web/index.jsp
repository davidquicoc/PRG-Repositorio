<%-- 
    Document   : index
    Created on : 7 may 2025, 17:11:45
    Author     : user
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    </head>
    <body>
        <div class="contenedor">
            <header>
                <div class="header-logo">
                    <a href="#">
                        <h2>LOGO</h2>
                    </a>
                </div>
                <nav class="header-nav">
                    <ul>
                        <li><a href="index.jsp">Inicio</a></li>
                        <li><a href="peliculas.jsp">Películas</a></li>
                        <li><a href="calendario.jsp">Calendario</a></li>
                        <%
                        if (session.getAttribute("usuario") != null) {
                        %>
                        <li><a href="gestionar.jsp">Gestionar</a></li>
                        <%
                            }
                        %>
                    </ul>
                </nav>
                <div class="header-user">
                    <%
                        if (session.getAttribute("usuario") == null) {
                    %>
                        <a href="login-form.jsp">Iniciar sesión</a>
                    <%
                        } else {
                    %>
                        <a href="user-profile.jsp"><%= session.getAttribute("usuario") %></a>
                    <%
                        }
                    %>
                </div>
            </header>
            <main>
                <h3>Sesiones</h3>
                <!-- sesiones -->
            </main>
        </div>
    </body>
</html>
