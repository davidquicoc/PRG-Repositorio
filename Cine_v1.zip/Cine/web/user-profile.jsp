<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Usuario <%= session.getAttribute("usuario")%> - Cine</title>
    </head>
    <body>
        <h2>Datos del usuario</h2>
        <p>Usuario <%= session.getAttribute("usuario")%></p>
        <!-- Por terminar -->
    </body>
</html>
