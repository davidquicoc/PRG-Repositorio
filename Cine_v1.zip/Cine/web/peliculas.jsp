<%-- 
    Document   : index
    Created on : 7 may 2025, 2:09:16
    Author     : user
--%>

<%@page import="java.sql.Statement"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@page import="programas.ConexionBD"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Inicio - Cine</title>
        <link rel="stylesheet" href="css/peliculas.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    </head>
    <body>
        <h2>Películas en la Base de Datos</h2>
        <%
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = ConexionBD.conectar();
            
            if (conexion == null) {
                response.sendRedirect("./error");
                return;
            }
            
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM pelicula ORDER BY titulo");
            %>
            <h4>Peliculas dadas de alta</h4>
            <%
            while (rs.next()) {
                if (rs.getBoolean("estado_pelicula")) {
            %>
            <div class="bloque">
            <%
                    out.println(rs.getString("ID_pelicula") + " | " + rs.getString("titulo") + " | " + rs.getString("genero") + " | " + rs.getInt("duracion") + " | " + rs.getInt("año") + " | " + rs.getString("clasificacion") + " | " + rs.getString("url") + " | " + rs.getBoolean("estado_pelicula") + "<br>");
                    out.println("<img src=\"" + rs.getString("url") + "\">");
                }%>
            </div>
            <%
            }
            %>
            <h4>Peliculas dadas de baja</h4>
            <%
            //  Crear conjunto de peliculas.
            /*while (rs.next()) {
                if (!rs.getBoolean("estado")) { 
                    out.println(rs.getString("ID_pelicula") + " | " + rs.getString("titulo") + " | " + rs.getString("genero") + " | " + rs.getInt("duracion") + " | " + rs.getInt("año") + " | " + rs.getString("clasificacion") + " | " + "<br>");
                }
            }*/
            
            conexion.close();
        %>
    </body>
</html>
