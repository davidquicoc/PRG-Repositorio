<%
    String usuario = request.getParameter("usuario");
    String contrase�a = request.getParameter("contrasena");
    
    if (usuario.equals("pepe") && contrase�a.equals("1234")) {
        session.setAttribute("usuario", usuario);
        response.sendRedirect("index.jsp");
    } else {
        session.setAttribute("error", "Acceso inv�lido. Por favor, int�ntelo otra vez");
        response.sendRedirect("login-form.jsp");
    }
%>