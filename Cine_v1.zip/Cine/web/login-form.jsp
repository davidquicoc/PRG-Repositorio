<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Iniciar sesión</title>
    </head>
    <body>
        <%
            if (session.getAttribute("usuario") != null) {
                response.sendRedirect("index.jsp");
            }
        %>
        <div>
            <h2>Iniciar sesión</h2>
            <form action="login.jsp">
                <input type="text" name="usuario" placeholder="Usuario"><br>
                <input type="text" name="contrasena" placeholder="Contraseña"><br>
                <input type="submit" value="Acceder"><br>
                <input type="button" value="Volver a la página de inicio">
            </form>
        </div>
    </body>
</html>
